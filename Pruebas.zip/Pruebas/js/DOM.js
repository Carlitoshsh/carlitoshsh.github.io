// Header
var header = '<nav class="navbar navbar-default">\
<div class="container-fluid">\
    <div class="navbar-header">\
        <a class="navbar-brand" href="#">Página de prueba</a>\
    </div>\
    <ul class="nav navbar-nav">\
        <div ng-controller="navegacion as barraDeNavegacion" >\
            <li ng-repeat="elemento in barraDeNavegacion.subMenus">\
                <a href="{{elemento.irArchivo}}">{{elemento.nombrePagina}}</a>\
            </li>\
        </div>\
    </ul>\
</div>\
</nav>';

var headerContainer = document.createElement("div");
headerContainer.innerHTML = header;

document.body.insertBefore(headerContainer, document.body.firstChild);